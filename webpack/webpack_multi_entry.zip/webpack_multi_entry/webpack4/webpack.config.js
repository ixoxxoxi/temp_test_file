const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
  entry: {
    index: '../src/index.js',
    admin: '../src/admin.js',
    login: '../src/login.js',
  },
  output: {
    filename: pathData => {
      const name = pathData.chunk.name;
      return name === 'index' ? 'js/[name].js' : '[name]/js/[name].js';
    },
    path: path.resolve(__dirname, './dist'),
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(),
    new HtmlWebpackPlugin({
      template: '../src/index.html',
      filename: 'index.html',
      chunks: ['index'],
    }),
    new HtmlWebpackPlugin({
      template: '../src/admin.html',
      filename: 'admin/index.html',
      chunks: ['admin'],
    }),
    new HtmlWebpackPlugin({
      template: '../src/login.html',
      filename: 'login/index.html',
      chunks: ['login'],
    }),
    new MiniCssExtractPlugin({
      filename: pathData => {
        const name = pathData.chunk.name;
        return name === 'index' ? 'css/[name].css' : '[name]/css/[name].css';
      },
    }),
  ],
  devServer: {
    contentBase: './dist',
    port: 3000,
    open: true,
  },
};
