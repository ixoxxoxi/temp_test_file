// 首页入口文件
import './style.css';
console.log('index 首页 - 打包到 dist 根目录');
document.write('<h1>Index 首页（dist 根目录）</h1>');
