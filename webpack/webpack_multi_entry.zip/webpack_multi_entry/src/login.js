// 登录入口文件
import './style.css';
console.log('login 登录 - 打包到 dist/login');
document.write('<h1>Login 页面（dist/login）</h1>');