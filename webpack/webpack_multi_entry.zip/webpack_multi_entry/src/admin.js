// 后台入口文件
import './style.css';
console.log('admin 后台 - 打包到 dist/admin');
document.write('<h1>Admin 页面（dist/admin）</h1>');
