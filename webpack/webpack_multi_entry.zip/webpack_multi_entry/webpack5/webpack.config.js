const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = {
  entry: {
    index: '../src/index.js',
    admin: '../src/admin.js',
    login: '../src/login.js',
  },
  output: {
    filename: pathData => {
      const name = pathData.chunk.name;
      return name === 'index' ? 'js/[name].js' : '[name]/js/[name].js';
    },
    path: path.resolve(__dirname, './dist'),
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: '../src/index.html',
      filename: 'index.html',
      chunks: ['index'],
    }),
    new HtmlWebpackPlugin({
      template: '../src/admin.html',
      filename: 'admin/index.html',
      chunks: ['admin'],
    }),
    new HtmlWebpackPlugin({
      template: '../src/login.html',
      filename: 'login/index.html',
      chunks: ['login'],
    }),
    new MiniCssExtractPlugin({
      filename: pathData => {
        const name = pathData.chunk.name;
        return name === 'index' ? 'css/[name].css' : '[name]/css/[name].css';
      },
    }),
  ],
  devServer: {
    port: 3000,
    open: true,
  },
};
